<template>
<div class="main">
  <v-container class="main">
  <v-card class="header">Everything you need to know about Abou's Five Start Restaurant!</v-card>
  <v-card class="text-xs-center">
  <img src="http://i65.tinypic.com/dzxoye.jpg">
  </v-card>
 <v-card class="p2">OUR SOURCING STORY
Our commitment to 
bringing you the best means that all of the
 seafood we serve is sourced in ways that are 
 traceable, sustainable, and responsible.
 headquartered in Orlando, Florida. The company has operations across the United States, and internationally in Ecuador, Canada, Malaysia, Saudi Arabia, the United Arab Emirates, Qatar, Mexico, and Japan. As of February 24, 2013, the company had 705 locations worldwide. Golden Gate Capital has been Red Lobster's parent company since it was acquired from Darden Restaurants on July 28, 2014.[4]
On August 6, 2014, Red Lobster announced their new headquarters location in CNL Center City Commons in Orlando.[5] On March 6, 2015, Red Lobster officially opened the Restaurant Support Center.[6]
Contents
1	History
1.1	Formation and growth
1.2	2009 Prototype and sale
2	Promotions
3	Menu
3.1	Lobster bisque controversy
4	Locations
5	See also
6	References
7	External links
History[edit]
Formation and growth[edit]
The first Red Lobster restaurant was opened on January 18, 1968, in Lakeland, Florida, by entrepreneurs Bill Darden and Charley Woodsby.[7][8] The oft-quoted date of March 1968 is based on the March 27, 1968, incorporation of Red Lobster Inns of America, Inc. (now GMRI, Inc.) in the Florida Secretary of State's Office.[9] Originally billed as a "Harbor for Seafood Lovers", the first restaurant was followed by four others throughout the southeast United States. In 1970, General Mills acquired Red Lobster as a five-unit company. With new backing, the chain expanded rapidly in the 1980s.
A Lobsterfest duo meal
Red Lobster entered Canada in the 1980s, in many cases by buying Ponderosa restaurant locations. The company generally maintains between 25 and 30 locations in Canada, the bulk in larger urban centres in Ontario (across southern Ontario plus one in Sudbury in northern Ontario) with a smaller number in larger urban centres in all three Prairie provinces. It exited the Quebec market in September 1997 due to financial losses, and never attempted to enter the market in British Columbia.[10]

On March 29, 1994, Bill Darden died, after an extended illness, at the age of 75.[11]

In 1995, Red Lobster (along with Olive Garden and other sister chains), became part of Darden Restaurants, Inc. During that time, General Mills decided to release Darden into an independent, publicly traded corporation.[3]

2009 Prototype and sale[edit]

The "Bar Harbor" prototype design as seen at the Baton Rouge, Louisiana location
In 2009, Red Lobster debuted its new Bar Harbor restaurant prototype modeled after coastal New England.[12] The new exterior features include shingle and stone towers, signal flags, and Adirondack-style benches. The interior updates include dark wood paneling, warm-toned fabrics, soft lighting, and nautical decor and artwork.[13]

On December 19, 2013, Darden Restaurants announced plans to sell or spin off the Red Lobster brand, citing pressure from stock investors.[14] This was in direct response to Darden going over budget on a new digital platform.[15] On May 12, 2014, Darden announced that as part of the spinoff of Red Lobster, it was converting the co-located Red Lobster and Olive Garden locations into standalone Olive Garden locations.[16] On May 16, 2014, Darden announced it would be selling the Red Lobster seafood restaurant chain to Golden Gate Capital for US$2.1 billion.[17] Darden announced the completion of the sale of Red Lobster on July 28, 2014.[18]

On August 6, 2014, Red Lobster announced their new headquarters location in CNL Center City Commons in Orlando.[5] On March 6, 2015, Red Lobster officially opened the Restaurant Support Center.[6]
Promotions[edit]
A basket of Cheddar Bay Biscuits from Red Lobster
Red Lobster has offered an endless snow crab leg promotion twice in its history. However, in 2003, the promotion resulted in parent company Darden Restaurants taking a $3 million charge to third-quarter earnings, resulting in president Edna Morris' departure from the company. The ill-timed promotio
 </v-card>
 <v-card class="text-xs-center"> 
   <p class="contact">Contact (444)-454-8786 for any concern. </p> 
   <p class="contact">Thank you for visiting Abou's Five Start Restaurant!</p>
   </v-card>
  </v-container>
  </div>
</template>
<script>
export default {
  name: 'Info',
  data: () => ({
    pictures:{

    }
  })
};
</script>

<style scoped>
.p2{
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
  padding: 20px;
  
}
.header{
  font-size: 50px;
  font-weight: bold;
  font-family: 'Times New Roman', Times, serif;
  padding:30px;
  margin-top: 30px;
}
.text-xs-center{
  font-family: 'Gill Sans', 'Gill Sans MT', Calibri, 'Trebuchet MS', sans-serif;
  font-size: 50px;
  padding: 30px;
  margin-top: 20px;
  justify-content: center;
}
.main{
  background-color: rgb(71, 51, 51);
}
.contact{
  font-size: 20px;
  font-weight: bold;
}
</style>
